<#

.SYNOPSIS
This Powershell script can be run on a server to gather a file collection from a NetWorker instance.
The generated files can be uploaded to LiveOpics through the collector for analysis. 

.DESCRIPTION
This script will run queries against NetWorker and produce .out files for analysis.

.LINK
https://www.liveoptics.com/

#>

#-----------------------------------------------------------------------------
#  Copyright (c) 2017-2019 by Dell Inc. 
# 
#  All rights reserved.  
# 
#-----------------------------------------------------------------------------


#
# Create a temporary directory
#
$dt=Get-Date -UFormat %Y%m%d%H%M%S
$tempDir="LiveOpticsNetWorker" + $dt
new-item -type directory -path $tempDir | Out-Null;

if (!(Test-Path $tempDir)) {
    
    Write-Error "Failed to create directory to hold file output: $tempDir";
    exit;
}

"Temporary directory created: " + $tempDir;


$ErrorActionPreference="SilentlyContinue"
Stop-Transcript | out-null
$ErrorActionPreference = "Continue"
Start-Transcript $tempDir\script-logs.txt -append

$scriptVersion="PowerShell.1.1.0";

""
"------------------------------------------------------";
"Live Optics collection script for NetWorker on Windows";
"------------------------------------------------------";
$date=Get-Date -Format o;
"Date: " + $date;
"Version: " + $scriptVersion;
""

#
# UTF-8 output to file without BOM
#
function Out-FileUtf8NoBom {

  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$True, Position=0)] [string] $LiteralPath,
    [switch] $Append,
    [switch] $NoClobber,
    [Parameter(ValueFromPipeline=$True)]
    [string[]]$lines
  )

  Begin
  {
	# Make sure that the .NET framework sees the same working dir. as PS
	# and resolve the input path to a full path.
	[System.IO.Directory]::SetCurrentDirectory($PWD) # Caveat: .NET Core doesn't support [Environment]::CurrentDirectory
	$LiteralPath = [IO.Path]::GetFullPath($LiteralPath)

	# If -NoClobber was specified, throw an exception if the target file already
	# exists.
	if ($NoClobber -and (Test-Path $LiteralPath)) {
		Throw [IO.IOException] "The file '$LiteralPath' already exists."
	}

	try {
		
		# Create a StreamWriter object.
		# Note that we take advantage of the fact that the StreamWriter class by default:
		# - uses UTF-8 encoding
		# - without a BOM.
		$sw = New-Object IO.StreamWriter $LiteralPath, $Append

	}
	catch {
		Write-Error "Failed to create output stream."
		Write-Error $_;
		exit;
    }	
  }
  
  Process { 
	try {
		ForEach ($line in $lines) {
			$sw.WriteLine($line)
		}
	}
	catch {
		$sw.Dispose();
		$sw = $null;
		
		Write-Error "Failed to write to stream."
		Write-Error $_;
		exit;
	}
  }
  
  End {
	if ($sw) {
		$sw.Dispose();
	}
  }
}


#
# Set the path
#
$env:Path="$env:Path;$env:ProgramFiles/Legato/nsr/bin";

#
# Date information - quick_date.out
#
$quick_date="$tempDir/nwquick_date.out";
$date=Get-Date -Uformat "%a %m/%d/%Y"
$date | Out-FileUtf8NoBom $quick_date;

#
# Improved date format
#
$quick_psdate="$tempDir/nwquick_psdate.out";
$date=Get-Date -Format o;
$date | Out-FileUtf8NoBom $quick_psdate;

#
# Script version
#
$quick_scriptVersion="$tempDir/nwquick_scriptVersion.out";
$scriptVersion | Out-FileUtf8NoBom $quick_scriptVersion;

#
#Windows version
#
$quick_osVersion="$tempDir/nwquick_windowsversion.out";
[environment]::OSVersion.Version | Out-FileUtf8NoBom $quick_osVersion

#
#Powershell version
#
$quick_psVersion="$tempDir/nwquick_psversion.out";
$PSVersionTable.PSVersion | Out-FileUtf8NoBom $quick_psVersion

#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) | Out-FileUtf8NoBom "$tempDir/nwquick_time.out";

#
# Timezone information - quick_timezone.out
#
$tz=(& reg query "HKLM\SYSTEM\CurrentControlSet\Control\TimeZoneInformation");
$quick_timezone="$tempDir/nwquick_timezone.out";
$tz | Out-FileUtf8NoBom $quick_timezone;

#
# Hostname information - quick_hostname.out
#
$hostnameFile="$tempDir/nwquick_hostname.out";
hostname | Out-FileUtf8NoBom $hostnameFile;

#
# Base date used for drawing the line on backups.
# 120 days is the default.
#
$last=(New-TimeSpan -Days (120));
$lastBackupDate=[System.DateTime]::UtcNow.Subtract($last);
$lastBackupDateString="-t " + $lastBackupDate.ToString("MM\/dd\/yyyy");
$lastBackupDateString | Out-FileUtf8NoBom "$tempDir/nwquick_timeconstraint.out";

#
# Dump environment variables
#
foreach ($e in (gci env:*)) { $e.Name + "=" + $e.Value | Out-FileUtf8NoBom "$tempDir/nwquick_set.out" -Append; }

#
# NetWorker Commands
#
$nsradmin="nsradmin";
$nsrlic="nsrlic";
$mminfo="mminfo";


#
# Get NetWorker version
#
$arrayVersionCommandFile="$tempDir/ArrayVersionCommandFile.txt";

"show version" | Out-FileUtf8NoBom $arrayVersionCommandFile;
"p NSR" | Out-FileUtf8NoBom $arrayVersionCommandFile -Append;

"Running command for NetWorker version: nsradmin -i";

& $nsradmin -i "$arrayVersionCommandFile" 2> "$tempDir/nwquick_nsradminversion_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradminversion.out";

#
# Parse major and minor versions
#
$NetworkerMajorVersion = 0;
$NetworkerMinorVersion = 0;

try
{
	if ( (test-path "$tempDir/nwquick_nsradminversion.out") -and ( (get-childitem "$tempDir/nwquick_nsradminversion.out").Length -gt 0) )
    {
		$VersionPattern = "NetWorker\s+(\d+)\.(\d+)";
	
		# Convert input file to a string
		if ([string](Get-Content -Path "$tempDir/nwquick_nsradminversion.out") -match $VersionPattern)	
        {
			if ($Matches.Count -eq 3)
            {
				$NetworkerMajorVersion = $Matches[1];
				$NetworkerMinorVersion = $Matches[2];				
				
				Write-Output "NetworkerMajorVersion = $NetworkerMajorVersion";
				Write-Output "NetworkerMinorVersion = $NetworkerMinorVersion";
			}
			else
			{
				Write-Error "ERROR.  Unable to parse NetWorker version.";
				exit;
			}
		}
		else
		{
			Write-Error "ERROR.  Unable to find NetWorker version.";
			exit;
		}
	}
	else
	{
		Write-Error "ERROR.  NetWorker version file does not exist or is empty.";
		exit;
	}
}
catch
{
	Write-Error "ERROR.  Failed to find Networker version file.";
	exit;
}


#
# Get configuration information (including time zone)
#
$commandFile="$tempDir/CommandFile.txt";

"show" | Out-FileUtf8NoBom $commandFile;
"option hidden" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append; 

"Running command: nsradmin -i";

& $nsradmin -i "$commandFile" 2> "$tempDir/nwquick_nsradmin_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradmin.out";



"Running command:  nsradmin -i";
"show" | Out-FileUtf8NoBom $commandFile;
"option hidden" | Out-FileUtf8NoBom $commandFile -Append;
". NSR" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append;
". NSR client" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append
". NSR pool" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append;
& "$nsradmin" -i "$commandFile" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradmin_single.out" 2> "$tempDir/nwquick_nsradmin_single_err.out";


#
# Check for errors
#
$errorFile="$tempDir/nwquick_nsradmin_err.out";

if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {
    Write-Error "ERROR.  Unable to run nsradmin.";
    exit;
}

"NetWorker Major version: " + $NetworkerMajorVersion;
"NetWorker Minor version: " + $NetworkerMinorVersion;

#
# Determine if -I option (ISO 8601) can be used.  Versions 9.2 and 18.x (and above) support it.
#
$isoTimestampFlag="";
if ( ( [int]$NetworkerMajorVersion -eq 9 -and [int]$NetworkerMinorVersion -ge 2 ) -or ( [int]$NetworkerMajorVersion -ge 18 ) )
{
	$isoTimestampFlag="-I";
}

echo "isoTimestampFlag = $isoTimestampFlag";


"Running command: nsrlic -v";
& $nsrlic -v 2> $tempDir/nwquick_nsrlic_2_err.out | Out-FileUtf8NoBom $tempdir/nwquick_nsrlic.out;

$errorFile="$tempDir/nwquick_mminfojobs_err.out";

$errorString="unknown report constraint:";
$mminfojobsout="$tempDir/nwquick_mminfojobs.out";

"Running command: mminfo";
& $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),clretent(50),vmname,backup_size,attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;

#
# Check for errors
#
if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {

	"Trying mminfo command for NetWorker version 7.5 or older...";
	remove-item $mminfojobsout;
    remove-item $errorFile;

    & $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),clretent(50),attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;
    
    if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {
    
		"Trying mminfo command for oldest supported NetWorker version ...";
	
        remove-item $errorFile;
		remove-item $mminfojobsout;
        
        & $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;
        
        if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {

            Write-Error "ERROR.  Failed to get job info.";
            cat $errorFile;
			cat $mminfojobsout;
            exit;
        }
    }
}
 
"Running command: mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r ssid,ssid(53)";
& $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r "ssid,ssid(53)" 2> "$tempDir/nwquick_mminfojobs_long_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfojobs_long.out"; 

"Running command: mminfo $isoTimestampFlag -av -xm Getting media info...";
& $mminfo $isoTimestampFlag -av -xm -r 'state,volume,written,pool,%used,read,capacity,avail,volflags,type,family,barcode,volid,location,volaccess,volretent(50),olabel,labeled,recycled,volattrs' 2> "$tempDir/nwquick_mminfomedia_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfomedia.out";

#
# Check for errors
#
$errorFile="$tempDir/nwquick_mminfomedia_err.out";

if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {
    
    Write-Error "ERROR.  Failed run the mminfo for the media information.";
    exit;
}

"Running command: mminfo $isoTimestampFlag -X -a -xm";
& $mminfo $isoTimestampFlag -X -a -xm 2> "$tempDir/nwquick_mminfosummary_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfosummary.out";


#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) | Out-FileUtf8NoBom "$tempDir/nwquick_time2.out";

#
# Clean up...
#
"File collection is complete."
"Files are located in the following folder:"

(Get-Item $tempDir).FullName;

"Launch the Live Optics collector and add this folder to your NetWorker collection.";

Stop-Transcript
# SIG # Begin signature block
# MIIiIwYJKoZIhvcNAQcCoIIiFDCCIhACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBX1G5yp8UtxVX7
# 00XQEFipkrpT3B9XDGX6x/z+kOX/0aCCClIwggUdMIIEBaADAgECAgxDwQscAAAA
# AFHTc9owDQYJKoZIhvcNAQELBQAwgb4xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1F
# bnRydXN0LCBJbmMuMSgwJgYDVQQLEx9TZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2Fs
# LXRlcm1zMTkwNwYDVQQLEzAoYykgMjAwOSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1
# dGhvcml6ZWQgdXNlIG9ubHkxMjAwBgNVBAMTKUVudHJ1c3QgUm9vdCBDZXJ0aWZp
# Y2F0aW9uIEF1dGhvcml0eSAtIEcyMB4XDTE1MDYxMDEzNDYwNVoXDTMwMTExMDE0
# MTYwNVowgbQxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSgw
# JgYDVQQLEx9TZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkwNwYDVQQL
# EzAoYykgMjAxNSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQgdXNlIG9u
# bHkxKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZDUzEwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDYhg2gZApq9Y6WujuaaGrbREDe
# 9S38621EWM+OcsNwLV5a1PkL2BE1l8Ap8TvuF6HWRLm/H0qY4BkOteNZCB1SjKCw
# iihBpKGGQFCzTceIQdo2k6dMPWMsA8uvjQAlEWlQIvZLAM7Dsi6Bhd0j3U5NtfDA
# qHT862xgKZhxj2j3tx3z+EOLYpUyhk/KyExLU/5RIDAe/wBEx15xmqUbiXRK/lM+
# hOqxo4md+C1CWNgKBlAjcBYcAneXGDzZEH0MeuYFLBoIFmYSOGxxHdZk11bAjTbD
# uLUAuN0vtXq/saRuePptEnbkmXcRpiTkgrlGeamwo0lb01N0Q4F0b6H4Li8lAgMB
# AAGjggEhMIIBHTAOBgNVHQ8BAf8EBAMCAQYwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# EgYDVR0TAQH/BAgwBgEB/wIBADAzBggrBgEFBQcBAQQnMCUwIwYIKwYBBQUHMAGG
# F2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6
# Ly9jcmwuZW50cnVzdC5uZXQvZzJjYS5jcmwwOwYDVR0gBDQwMjAwBgRVHSAAMCgw
# JgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMB0GA1UdDgQW
# BBR+Gh8aEXRcZMkMH5QBq/2BZC6hLDAfBgNVHSMEGDAWgBRqciZ60B7vfec7aVHU
# bI2fkBJmqzANBgkqhkiG9w0BAQsFAAOCAQEAt3RntD5MJS9iNYGc0nblp+IoeHTD
# 7BnlE/m2I5RPYqdM5k5ywiSQ0Hm6qM3XRN8AOTDxKMRyb3iskAsto+qFrRTCCxSZ
# P/sjdK2oqswiYzIlASvK0BZGQlqnREdYHQRB4tExvpdhO64EGGx6eoFfqyL+CNY1
# jqcN9ewg3Nxtx6J22PtmqEMDASGooPZM5tSCztcNAdYzrJCj4JK7GAJ1QwJ6BLTY
# Fe1XkTwS541m+L0UzEaC1voDwAoNfLGAD+uhGjaldR882Drq55WB3qxa+521zBFO
# KnQR1n95QmHKIUFgHqTd8dl0sNWl6AtMgYnfzIYWJRmlFFeVoooie7FljTCCBS0w
# ggQVoAMCAQICEF/yYuPhvd+2AAAAAFVmvDEwDQYJKoZIhvcNAQELBQAwgbQxCzAJ
# BgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSgwJgYDVQQLEx9TZWUg
# d3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkwNwYDVQQLEzAoYykgMjAxNSBF
# bnRydXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxKDAmBgNVBAMT
# H0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZDUzEwHhcNMjAwMzE3MjAxMTEw
# WhcNMjEwNTIyMjA0MTA4WjCBijELMAkGA1UEBhMCVVMxDjAMBgNVBAgTBVRleGFz
# MRMwEQYDVQQHEwpSb3VuZCBSb2NrMR8wHQYDVQQKExZEZWxsIFRlY2hub2xvZ2ll
# cyBJbmMuMRQwEgYDVQQLEwtMaXZlIE9wdGljczEfMB0GA1UEAxMWRGVsbCBUZWNo
# bm9sb2dpZXMgSW5jLjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALmd
# 3m9PM5OxvfiF+zV/DiXJnjaveCUMLGx4L9acT2bWG9vFPo2As+XjwJxCLBkONOUU
# CnWyreVNWuif2wExTJGPcCkxhw0FLw1UHGQsrAXkN/H6jgsg6sdoJXgY4iDtWFKc
# YZ4bT7hxGzYdZWXs70koVNrhPcJtzXMtBSCfQdtGUeyq+rOg1Yqydqja322yvw+7
# rm8hy4LI0otWf+e3M7QEnyfNoBqSiCM/PzW8gSwmejLcFYMB1RksQIHFcKxaMMEQ
# nVSQBPj+UuyfFfB6C7peYaFk0lFnMK7RqnY9wGhMXc0H0yFmBTYV8cM0XKTOGglE
# c5i+TE+OLvpb91Y32LcCAwEAAaOCAWEwggFdMA4GA1UdDwEB/wQEAwIHgDATBgNV
# HSUEDDAKBggrBgEFBQcDAzBqBggrBgEFBQcBAQReMFwwIwYIKwYBBQUHMAGGF2h0
# dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDUGCCsGAQUFBzAChilodHRwOi8vYWlhLmVu
# dHJ1c3QubmV0L292Y3MxLWNoYWluMjU2LmNlcjAxBgNVHR8EKjAoMCagJKAihiBo
# dHRwOi8vY3JsLmVudHJ1c3QubmV0L292Y3MxLmNybDBMBgNVHSAERTBDMDcGCmCG
# SAGG+mwKAQMwKTAnBggrBgEFBQcCARYbaHR0cDovL3d3dy5lbnRydXN0Lm5ldC9y
# cGEgMAgGBmeBDAEEATAfBgNVHSMEGDAWgBR+Gh8aEXRcZMkMH5QBq/2BZC6hLDAd
# BgNVHQ4EFgQUGmcdozhjZ8S99R4K0wC1ebjwG/gwCQYDVR0TBAIwADANBgkqhkiG
# 9w0BAQsFAAOCAQEATJUY6v/eUX9otHmYd5UThAdo+owL5eKnXMuro4BsWJvCbjwL
# HrpFcLptGPmJz5+AZA/2ZqMtNG9xwEcNgnTX6YKW0rP3CSfMsgxBSG9vJqUyh6EZ
# Q0ONt++ak9y7w6+SVzj0I9is9dl0zr9BcvySQ2Rqt3X4lkexWpNPnnfXWYRDG44Y
# N2YNsC+gqKBdVZ5Y3tE//QHLEB2IaCdvsow/AK/IEbTXh7sPZ/oV2rHeI/AXmEQi
# wdxav6Pb4RFN75mpRZ+aQcx5SwkHb31vmyEDnm4/L2ZaFwcdIxVdRclto+no321k
# n1tGGEy864dmQtviFsjqmhQSdPrqrwRbBaZ5mzGCFycwghcjAgEBMIHJMIG0MQsw
# CQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMfU2Vl
# IHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIwMTUg
# RW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MSgwJgYDVQQD
# Ex9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MxAhBf8mLj4b3ftgAAAABV
# ZrwxMA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIAeYB/rSZcwUhbz36aZMvEEBM+vvAHjNToQEyVlJV6ba
# MA0GCSqGSIb3DQEBAQUABIIBAJo8CGMDwv6UpdMYAoBS8gK2V1vmaL7YI1vQKQfl
# WX/PSt67ziCIlrxTDD68SVWd6RyuKWj1rb+Sr2dYEExn5Tn1AlvuyP7kqI4o6RmP
# xckNbbtdxI41Nom/EZi+dB+liSL50XF6WipAU+i9X7UE+pS1Vl/joPergNnjgq+k
# iRAz+LIWbqnTf8BrutydquOB+7ZlSL0E89NYjP/c7oWjkz+WUzunKhMVUXSWsKok
# 2T5JL1Ho0BWW4RUM3eXtXHWE99cUljlZ37OlyIZdQFHZiNdZfq2mleWWDIpzMr4C
# 53HqNtqNReCJ2mbU6qdKnnVhlT+TQnMMu8utnx/2hrWhuyahghSwMIIUrAYKKwYB
# BAGCNwMDATGCFJwwghSYBgkqhkiG9w0BBwKgghSJMIIUhQIBAzEPMA0GCWCGSAFl
# AwQCAQUAMHAGCyqGSIb3DQEJEAEEoGEEXzBdAgEBBgpghkgBhvpsCgMFMDEwDQYJ
# YIZIAWUDBAIBBQAEIM2d4NDuDB0kdh8S/ylfX1cEm5tUeXRJsM+1/n9hkZyaAggc
# BwQe/xMu4hgPMjAyMTAyMjIxMzMwNTZaoIIPVTCCBCowggMSoAMCAQICBDhj3vgw
# DQYJKoZIhvcNAQEFBQAwgbQxFDASBgNVBAoTC0VudHJ1c3QubmV0MUAwPgYDVQQL
# FDd3d3cuZW50cnVzdC5uZXQvQ1BTXzIwNDggaW5jb3JwLiBieSByZWYuIChsaW1p
# dHMgbGlhYi4pMSUwIwYDVQQLExwoYykgMTk5OSBFbnRydXN0Lm5ldCBMaW1pdGVk
# MTMwMQYDVQQDEypFbnRydXN0Lm5ldCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAo
# MjA0OCkwHhcNOTkxMjI0MTc1MDUxWhcNMjkwNzI0MTQxNTEyWjCBtDEUMBIGA1UE
# ChMLRW50cnVzdC5uZXQxQDA+BgNVBAsUN3d3dy5lbnRydXN0Lm5ldC9DUFNfMjA0
# OCBpbmNvcnAuIGJ5IHJlZi4gKGxpbWl0cyBsaWFiLikxJTAjBgNVBAsTHChjKSAx
# OTk5IEVudHJ1c3QubmV0IExpbWl0ZWQxMzAxBgNVBAMTKkVudHJ1c3QubmV0IENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5ICgyMDQ4KTCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBAK1NS6kShrLqoyAHFRZkKitL0b8LSk2O7YB2pWe3eEDAc0LI
# aMDbUyvdXrh2mDWTixqdfBM6Dh9btx7P5SQUHrGBqY19uMxrSwPxAgzcq6VAJAB/
# dJShnQgps4gL9Yd3nVXN5MN+12pkq4UUhpVblzJQbz3IumYM4/y9uEnBdolJGf3A
# qL2Jo2cvxp+8cRlguC3pLMmQdmZ7lOKveNZlU1081pyyzykD+S+kULLUSM4FMlWK
# /bJkTA7kmAd123/fuQhVYIUwKfl7SKRphuM1Px6GXXp6Fb3vAI4VIlQXAJAmk7wO
# SWiRv/hH052VQsEOTd9vJs/DGCFiZkNw1tXAB+ECAwEAAaNCMEAwDgYDVR0PAQH/
# BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFFXkgdERgL7YibkIozH5
# oSQJFrlwMA0GCSqGSIb3DQEBBQUAA4IBAQA7m49WmzDnU5l8enmnTZfXGZWQ+wYf
# yjN8RmOPlmYk+kAbISfK5nJz8k/+MZn9yAxMaFPGgIITmPq2rdpdPfHObvYVEZSC
# DO4/la8Rqw/XL94fA49XLB7Ju5oaRJXrGE+mH819VxAvmwQJWoS1btgdOuHWntFs
# eV55HBTF49BMkztlPO3fPb6m5ZUaw7UZw71eW7v/I+9oGcsSkydcAy1vMNAethqs
# 3lr30aqoJ6b+eYHEeZkzV7oSsKngQmyTylbe/m2ECwiLfo3q15ghxvPnPHkvXpzR
# TBWN4ewiN8yaQwuX3ICQjbNnm29ICBVWz7/xK3xemnbpWZDFfIM1EWVRMIIFEzCC
# A/ugAwIBAgIMWNoT/wAAAABRzg33MA0GCSqGSIb3DQEBCwUAMIG0MRQwEgYDVQQK
# EwtFbnRydXN0Lm5ldDFAMD4GA1UECxQ3d3d3LmVudHJ1c3QubmV0L0NQU18yMDQ4
# IGluY29ycC4gYnkgcmVmLiAobGltaXRzIGxpYWIuKTElMCMGA1UECxMcKGMpIDE5
# OTkgRW50cnVzdC5uZXQgTGltaXRlZDEzMDEGA1UEAxMqRW50cnVzdC5uZXQgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkgKDIwNDgpMB4XDTE1MDcyMjE5MDI1NFoXDTI5
# MDYyMjE5MzI1NFowgbIxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJ
# bmMuMSgwJgYDVQQLEx9TZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkw
# NwYDVQQLEzAoYykgMjAxNSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQg
# dXNlIG9ubHkxJjAkBgNVBAMTHUVudHJ1c3QgVGltZXN0YW1waW5nIENBIC0gVFMx
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2SPmFKTofEuFcVj7+IHm
# cotdRsOIAB840Irh1m5WMOWv2mRQfcITOfu9ZrTahPuD0Cgfy3boYFBpm/POTxPi
# wT7B3xLLMqP4XkQiDsw66Y1JuWB0yN5UPUFeQ18oRqmmt8oQKyK8W01bjBdlEob9
# LHfVxaCMysKD4EdXfOdwrmJFJzEYCtTApBhVUvdgxgRLs91oMm4QHzQRuBJ4ZPHu
# qeD347EijzRaZcuK9OFFUHTfk5emNObQTDufN0lSp1NOny5nXO2W/KW/dFGI46qO
# vdmxL19QMBb0UWAia5nL/+FUO7n7RDilCDkjm2lH+jzE0Oeq30ay7PKKGawpsjiV
# dQIDAQABo4IBIzCCAR8wEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMC
# AQYwOwYDVR0gBDQwMjAwBgRVHSAAMCgwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cu
# ZW50cnVzdC5uZXQvcnBhMDMGCCsGAQUFBwEBBCcwJTAjBggrBgEFBQcwAYYXaHR0
# cDovL29jc3AuZW50cnVzdC5uZXQwMgYDVR0fBCswKTAnoCWgI4YhaHR0cDovL2Ny
# bC5lbnRydXN0Lm5ldC8yMDQ4Y2EuY3JsMBMGA1UdJQQMMAoGCCsGAQUFBwMIMB0G
# A1UdDgQWBBTDwnHSe9doBa47OZs0JQxiA8dXaDAfBgNVHSMEGDAWgBRV5IHREYC+
# 2Im5CKMx+aEkCRa5cDANBgkqhkiG9w0BAQsFAAOCAQEAHSTnmnRbqnD8sQ4xRdcs
# AH9mOiugmjSqrGNtifmf3w13/SQj/E+ct2+P8/QftsH91hzEjIhmwWONuld307ga
# HshRrcxgNhqHaijqEWXezDwsjHS36FBD08wo6BVsESqfFJUpyQVXtWc26Dypg+9B
# wSEW0373LRFHZnZgghJpjHZVcw/fL0td6Wwj+Af2tX3WaUWcWH1hLvx4S0NOiZFG
# RCygU6hFofYWWLuRE/JLxd8LwOeuKXq9RbPncDDnNI7revbTtdHeaxOZRrOL0k2T
# dbXxb7/cACjCJb+856NlNOw/DR2XjPqqiCKkGDXbBY524xDIKY9j0K6sGNnaxJ9R
# EjCCBgwwggT0oAMCAQICEQCNzhXzp5TFhwAAAABVkjP0MA0GCSqGSIb3DQEBCwUA
# MIGyMQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UE
# CxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMp
# IDIwMTUgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MSYw
# JAYDVQQDEx1FbnRydXN0IFRpbWVzdGFtcGluZyBDQSAtIFRTMTAeFw0yMDA3MjIx
# NTMzMjlaFw0zMDEyMjkxNjI5MjNaMHUxCzAJBgNVBAYTAkNBMRAwDgYDVQQIEwdP
# bnRhcmlvMQ8wDQYDVQQHEwZPdHRhd2ExFjAUBgNVBAoTDUVudHJ1c3QsIEluYy4x
# KzApBgNVBAMTIkVudHJ1c3QgVGltZXN0YW1wIEF1dGhvcml0eSAtIFRTQTEwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDKPuwkYuH3/t/RNqk3ZtZ5FxSU
# QgCkhpe4J4zrT6n3067iqzAECChfm1Omh4ot3QJSX7W45bZQ8JyrEsHuGlZ4im5E
# P6mKj9fbU9nGR8gM3EZXAGcGFxqFt0Cqr3YH55BflJLVrtbXzXmhxTUrRIRfSRzV
# c7iBjXKUAmqpz1aSqjaUw1DJVpeIXOF/X/373xSOPaskDfZ7j2r6bh76lb19kPjk
# QhS/VV4EVJMxQ/fD58IFEWisQGnHIzfsWkwpyd81s35JTsZ6287CJZSeNz+I7CRN
# OY9/7xVrVExx8Q0hfFp10IdTiaBb4B37nAfAqKG0ItBipMcXfzdOzi06WOPl8CaG
# TUIHn76j4hmia3KlRr/LZFslyEX03ug8tv2c86Dvg0F8NnCQw1JisMd/PXvlloel
# Vv8O6kkF37TdE29F05vII3kqMJmdmdzMzaUugVNSIvLQPaI3UpGRRnDWxUsF/070
# 3GQGl/58kIYnr580VUiJqyLAdQeMIdkE0xyn6m2kyVIr4sQCiTBe55sx5jllrXGt
# 72db3KMk7Q3m4ql6OhhV3vBGLjRNGk2YgA1O0WyFdbgDwgDVIkom0Y7d7bXUJ9Y6
# fGdphtdUP5fPZL6Rq262nRkQebWXDvTRhcnkrsfAtKoHxB/BOlefzQ6meuUVhrKq
# 9KKTLM+M91H63YzQSQIDAQABo4IBVzCCAVMwDgYDVR0PAQH/BAQDAgeAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEEGA1UdIAQ6MDgwNgYKYIZIAYb6bAoDBTAoMCYG
# CCsGAQUFBwIBFhpodHRwOi8vd3d3LmVudHJ1c3QubmV0L3JwYTAJBgNVHRMEAjAA
# MGgGCCsGAQUFBwEBBFwwWjAjBggrBgEFBQcwAYYXaHR0cDovL29jc3AuZW50cnVz
# dC5uZXQwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9haWEuZW50cnVzdC5uZXQvdHMxLWNo
# YWluMjU2LmNlcjAxBgNVHR8EKjAoMCagJKAihiBodHRwOi8vY3JsLmVudHJ1c3Qu
# bmV0L3RzMWNhLmNybDAfBgNVHSMEGDAWgBTDwnHSe9doBa47OZs0JQxiA8dXaDAd
# BgNVHQ4EFgQULVaA7473SkMcQ6G13tnXqKprJigwDQYJKoZIhvcNAQELBQADggEB
# AFhLztj+gddR2MdcjZLSTpUehYZD7eAa5pohQjNd45G++FB8dowlqUHUhJno6KK2
# mZdooiC9MqiqKXwKdhqfyFWOq9N71ON+WX6ScDkP7fYv80//dFzz5zA0QKMRo2ty
# pDIRBXz9kYtHqFc2Usf6tUWE0bI+QuUWXt0D06n9PXBnetoT4ISCZzhgVsOtsIjh
# Cjd+YoEGuyME71igI6jRCWMwzdkZOPTrWndYvl+/65Qt/y8EMGQQjz5ZVi46Nk8O
# PJYPj8nqfn9JMh+jX27aIp/X2Rc5Wd5IF3oCS1hx/7cMLaHwZ6MR3PfJvNkey2wM
# FSd4SBZrLPGtl7h1bLuVw44xggSiMIIEngIBATCByDCBsjELMAkGA1UEBhMCVVMx
# FjAUBgNVBAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVz
# dC5uZXQvbGVnYWwtdGVybXMxOTA3BgNVBAsTMChjKSAyMDE1IEVudHJ1c3QsIElu
# Yy4gLSBmb3IgYXV0aG9yaXplZCB1c2Ugb25seTEmMCQGA1UEAxMdRW50cnVzdCBU
# aW1lc3RhbXBpbmcgQ0EgLSBUUzECEQCNzhXzp5TFhwAAAABVkjP0MA0GCWCGSAFl
# AwQCAQUAoIIBqjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTIxMDIyMjEzMzA1NlowLQYJKoZIhvcNAQk0MSAwHjANBglghkgBZQME
# AgEFAKENBgkqhkiG9w0BAQsFADAvBgkqhkiG9w0BCQQxIgQgqhGEy9j6tTod81eq
# XtDHq+06eMeQmlVn2es4ar0ijqkwggEMBgsqhkiG9w0BCRACLzGB/DCB+TCB9jCB
# 8wQglQom/cfAIBjp95GpXDjybu89pDJnyrDNFaVVr2MQcskwgc4wgbikgbUwgbIx
# CzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSgwJgYDVQQLEx9T
# ZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkwNwYDVQQLEzAoYykgMjAx
# NSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJjAkBgNV
# BAMTHUVudHJ1c3QgVGltZXN0YW1waW5nIENBIC0gVFMxAhEAjc4V86eUxYcAAAAA
# VZIz9DANBgkqhkiG9w0BAQsFAASCAgBm+pUC/bevmjtZp8ckiHW4YHrNCM9uzAa2
# KH2ry+F4OMYECST9Wd3K2I58eYuW6RpQ9kck6LTZusspt3XQXy92XoFJl9Lzo9py
# XQn4iaO7dfemRWtJks7nac3zGa/x7U6BOLc76dM+oiIL6pNVh3hNdbRHUPW4cqts
# J6/LKdDH2h7KE9MNC8pdil18Rt4PObG7XKNGUrfBfW09wLsNa20LJLsxZ49BMwCU
# mF/h8FhvEdLDAQeieh3IzWDwseWY1DajJ5NjuXEeSMn8D9nw/SAYLO8O092SaEEY
# SiwgP/RT7bDRSm93ODPrTwD1ipMXRcFjXcrz2i+zVAwPIJXva74VfVBhVefgNoEq
# 8vm4WhbedBaC69iwimojx0pEGJpWrPCgoBaxwiuDbuZ5AVz9JY3Gu8F8Xc3ziQ8z
# /vsDfxYSpPGEWyCI/epIuhr6LDYUaOtFhr0hx5IXLhyyFIqwXG4gCPAQawcn607J
# XdcLB191XDPGp/2TzFVMegDTYxsp4kDVb1AkEr4zYq855vTeIrCGqXn068TfOYCf
# b/BUewCIPNdbFKakAxToOkVCEPjqrBrZnHSbqmRG6EVmyWouubuyd5Tw1iTRy7rj
# WPAu85S8lxhR8UOss9MoKlqzP8X0B4HK3RJGAg1K2WYyEEQe1tOL6t5oKNL0lwbO
# hWJ9wsQ5Jg==
# SIG # End signature block
